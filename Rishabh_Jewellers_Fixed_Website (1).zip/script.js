/* Rishabh Jewellers — collection pages */
"use strict";

const WHATSAPP_NUMBER = "919964420860";
const ALTERNATE_WHATSAPP_NUMBER = "919341229404";

const collections = [
  {
    "id": "tirupati",
    "name": "Tirupati Dollar",
    "count": 13,
    "cover": "images/tirupati-01.png",
    "description": "13 supplied designs. Select any product picture to view it larger and enquire on WhatsApp.",
    "products": [
      {
        "name": "Tirupati Dollar 01",
        "ref": "RJ-101",
        "image": "images/tirupati-01.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Tirupati Dollar 02",
        "ref": "RJ-102",
        "image": "images/tirupati-02.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Tirupati Dollar 03",
        "ref": "RJ-103",
        "image": "images/tirupati-03.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Tirupati Dollar 04",
        "ref": "RJ-104",
        "image": "images/tirupati-04.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Tirupati Dollar 05",
        "ref": "RJ-105",
        "image": "images/tirupati-05.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Tirupati Dollar 06",
        "ref": "RJ-106",
        "image": "images/tirupati-06.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Tirupati Dollar 07",
        "ref": "RJ-107",
        "image": "images/tirupati-07.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Tirupati Dollar 08",
        "ref": "RJ-108",
        "image": "images/tirupati-08.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Tirupati Dollar 09",
        "ref": "RJ-109",
        "image": "images/tirupati-09.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Tirupati Dollar 10",
        "ref": "RJ-110",
        "image": "images/tirupati-10.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Tirupati Dollar 11",
        "ref": "RJ-111",
        "image": "images/tirupati-11.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Tirupati Dollar 12",
        "ref": "RJ-112",
        "image": "images/tirupati-12.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Tirupati Dollar 13",
        "ref": "RJ-113",
        "image": "images/tirupati-13.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      }
    ]
  },
  {
    "id": "temple-necklace",
    "name": "Temple Antique Necklace",
    "count": 13,
    "cover": "images/temple-necklace-01.png",
    "description": "13 supplied designs. Select any product picture to view it larger and enquire on WhatsApp.",
    "products": [
      {
        "name": "Temple Antique Necklace 01",
        "ref": "RJ-201",
        "image": "images/temple-necklace-01.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Temple Antique Necklace 02",
        "ref": "RJ-202",
        "image": "images/temple-necklace-02.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Temple Antique Necklace 03",
        "ref": "RJ-203",
        "image": "images/temple-necklace-03.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Temple Antique Necklace 04",
        "ref": "RJ-204",
        "image": "images/temple-necklace-04.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Temple Antique Necklace 05",
        "ref": "RJ-205",
        "image": "images/temple-necklace-05.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Temple Antique Necklace 06",
        "ref": "RJ-206",
        "image": "images/temple-necklace-06.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Temple Antique Necklace 07",
        "ref": "RJ-207",
        "image": "images/temple-necklace-07.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Temple Antique Necklace 08",
        "ref": "RJ-208",
        "image": "images/temple-necklace-08.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Temple Antique Necklace 09",
        "ref": "RJ-209",
        "image": "images/temple-necklace-09.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Temple Antique Necklace 10",
        "ref": "RJ-210",
        "image": "images/temple-necklace-10.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Temple Antique Necklace 11",
        "ref": "RJ-211",
        "image": "images/temple-necklace-11.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Temple Antique Necklace 12",
        "ref": "RJ-212",
        "image": "images/temple-necklace-12.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Temple Antique Necklace 13",
        "ref": "RJ-213",
        "image": "images/temple-necklace-13.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      }
    ]
  },
  {
    "id": "ganesha",
    "name": "Ganesha Pendant",
    "count": 13,
    "cover": "images/ganesha-01.png",
    "description": "13 supplied designs. Select any product picture to view it larger and enquire on WhatsApp.",
    "products": [
      {
        "name": "Ganesha Pendant 01",
        "ref": "RJ-301",
        "image": "images/ganesha-01.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Ganesha Pendant 02",
        "ref": "RJ-302",
        "image": "images/ganesha-02.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Ganesha Pendant 03",
        "ref": "RJ-303",
        "image": "images/ganesha-03.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Ganesha Pendant 04",
        "ref": "RJ-304",
        "image": "images/ganesha-04.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Ganesha Pendant 05",
        "ref": "RJ-305",
        "image": "images/ganesha-05.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Ganesha Pendant 06",
        "ref": "RJ-306",
        "image": "images/ganesha-06.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Ganesha Pendant 07",
        "ref": "RJ-307",
        "image": "images/ganesha-07.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Ganesha Pendant 08",
        "ref": "RJ-308",
        "image": "images/ganesha-08.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Ganesha Pendant 09",
        "ref": "RJ-309",
        "image": "images/ganesha-09.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Ganesha Pendant 10",
        "ref": "RJ-310",
        "image": "images/ganesha-10.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Ganesha Pendant 11",
        "ref": "RJ-311",
        "image": "images/ganesha-11.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Ganesha Pendant 12",
        "ref": "RJ-312",
        "image": "images/ganesha-12.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Ganesha Pendant 13",
        "ref": "RJ-313",
        "image": "images/ganesha-13.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      }
    ]
  },
  {
    "id": "calcutta",
    "name": "Calcutta Necklace",
    "count": 23,
    "cover": "images/calcutta-01.png",
    "description": "23 supplied designs. Select any product picture to view it larger and enquire on WhatsApp.",
    "products": [
      {
        "name": "Calcutta Necklace 01",
        "ref": "RJ-401",
        "image": "images/calcutta-01.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Calcutta Necklace 02",
        "ref": "RJ-402",
        "image": "images/calcutta-02.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Calcutta Necklace 03",
        "ref": "RJ-403",
        "image": "images/calcutta-03.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Calcutta Necklace 04",
        "ref": "RJ-404",
        "image": "images/calcutta-04.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Calcutta Necklace 05",
        "ref": "RJ-405",
        "image": "images/calcutta-05.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Calcutta Necklace 06",
        "ref": "RJ-406",
        "image": "images/calcutta-06.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Calcutta Necklace 07",
        "ref": "RJ-407",
        "image": "images/calcutta-07.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Calcutta Necklace 08",
        "ref": "RJ-408",
        "image": "images/calcutta-08.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Calcutta Necklace 09",
        "ref": "RJ-409",
        "image": "images/calcutta-09.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Calcutta Necklace 10",
        "ref": "RJ-410",
        "image": "images/calcutta-10.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Calcutta Necklace 11",
        "ref": "RJ-411",
        "image": "images/calcutta-11.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Calcutta Necklace 12",
        "ref": "RJ-412",
        "image": "images/calcutta-12.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Calcutta Necklace 13",
        "ref": "RJ-413",
        "image": "images/calcutta-13.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Calcutta Necklace 14",
        "ref": "RJ-414",
        "image": "images/calcutta-14.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Calcutta Necklace 15",
        "ref": "RJ-415",
        "image": "images/calcutta-15.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Calcutta Necklace 16",
        "ref": "RJ-416",
        "image": "images/calcutta-16.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Calcutta Necklace 17",
        "ref": "RJ-417",
        "image": "images/calcutta-17.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Calcutta Necklace 18",
        "ref": "RJ-418",
        "image": "images/calcutta-18.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Calcutta Necklace 19",
        "ref": "RJ-419",
        "image": "images/calcutta-19.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Calcutta Necklace 20",
        "ref": "RJ-420",
        "image": "images/calcutta-20.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Calcutta Necklace 21",
        "ref": "RJ-421",
        "image": "images/calcutta-21.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Calcutta Necklace 22",
        "ref": "RJ-422",
        "image": "images/calcutta-22.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      },
      {
        "name": "Calcutta Necklace 23",
        "ref": "RJ-423",
        "image": "images/calcutta-23.png",
        "weight": "",
        "note": "Please confirm net weight, purity, price and availability with the showroom."
      }
    ]
  }
];

const byId = id => document.getElementById(id);
const escapeHTML = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const whatsappURL = (message, phone = WHATSAPP_NUMBER) =>
  `https://wa.me/${String(phone).replace(/\D/g, "")}?text=${encodeURIComponent(message)}`;

const collectionsGrid = byId("collectionsGrid");
const productsGrid = byId("productsGrid");
const collectionTitle = byId("collectionTitle");
const collectionDescription = byId("collectionDescription");
const modal = byId("modal");
const modalImage = byId("modalImage");
const modalTitle = byId("modalTitle");
const modalDesc = byId("modalDesc");
const modalLink = byId("modalLink");
let currentCollection = null;
let lastFocusedElement = null;

function collectionURL(id) {
  return `collection.html?id=${encodeURIComponent(id)}`;
}

function renderCollections() {
  if (!collectionsGrid) return;
  collectionsGrid.innerHTML = collections.map(c => `
    <article class="collection" aria-label="${escapeHTML(c.name)} collection">
      <div class="collection-image">
        <img loading="lazy" src="${escapeHTML(c.cover)}" alt="${escapeHTML(c.name)}"
          onerror="this.onerror=null;this.alt='Product image unavailable';">
      </div>
      <div class="collection-info">
        <h3>${escapeHTML(c.name)}</h3>
        <p>${c.count} designs in this collection</p>
        <a class="collection-link" href="${collectionURL(c.id)}">Open collection ↗</a>
      </div>
    </article>`).join("");
}

function renderProducts(collection) {
  if (!productsGrid || !collection) return;
  currentCollection = collection;
  collectionTitle.textContent = collection.name;
  collectionDescription.textContent = collection.description;
  document.title = `${collection.name} | Rishabh Jewellers`;

  productsGrid.innerHTML = collection.products.map((p, i) => {
    const message = `Hello Rishabh Jewellers, please share price, net weight, purity and availability for ${p.name} (${p.ref}) from ${collection.name}.`;
    return `<article class="product-card">
      <div class="product-image-wrap" role="button" tabindex="0"
           aria-label="View ${escapeHTML(p.name)} larger" data-product-index="${i}">
        <img class="product-image" loading="lazy" src="${escapeHTML(p.image)}"
             alt="${escapeHTML(p.name)}"
             onerror="this.onerror=null;this.alt='Image unavailable';">
        <span class="product-tag">${escapeHTML(collection.name)}</span>
      </div>
      <div class="product-info">
        <p class="product-reference">Design reference ${escapeHTML(p.ref)}</p>
        <h3 class="product-name">${escapeHTML(p.name)}</h3>
        <p class="product-weight">Net weight: please enquire</p>
        <p class="product-note">${escapeHTML(p.note)}</p>
        <a class="product-wa" href="${whatsappURL(message)}" target="_blank" rel="noopener noreferrer">Enquire on WhatsApp ↗</a>
        <a class="alternate-wa" href="${whatsappURL(message, ALTERNATE_WHATSAPP_NUMBER)}" target="_blank" rel="noopener noreferrer">WhatsApp alternate number ↗</a>
      </div>
    </article>`;
  }).join("");
}

function openProduct(index) {
  if (!currentCollection || !modal) return;
  const p = currentCollection.products[index];
  if (!p) return;
  lastFocusedElement = document.activeElement;
  modalImage.src = p.image;
  modalImage.alt = p.name;
  modalTitle.textContent = p.name;
  modalDesc.textContent = `${currentCollection.name} · Design reference ${p.ref} · Please enquire for net weight.`;
  const message = `Hello Rishabh Jewellers, please share price, net weight, purity and availability for ${p.name} (${p.ref}) from ${currentCollection.name}.`;
  modalLink.href = whatsappURL(message);
  modal.classList.add("open");
  modal.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
  byId("close")?.focus();
}

function closeProductModal() {
  if (!modal) return;
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
  lastFocusedElement?.focus?.();
}

function initHome() {
  renderCollections();
  byId("hamb")?.addEventListener("click", () => byId("nav")?.classList.toggle("open"));
  byId("nav")?.querySelectorAll("a").forEach(a =>
    a.addEventListener("click", () => byId("nav")?.classList.remove("open"))
  );
}

function initCollectionPage() {
  const params = new URLSearchParams(window.location.search);
  const id = params.get("id");
  const collection = collections.find(c => c.id === id) || collections[0];
  renderProducts(collection);

  byId("backToCollections")?.addEventListener("click", e => {
    e.preventDefault();
    window.location.href = "index.html#collections";
  });

  productsGrid?.addEventListener("click", e => {
    const wrap = e.target.closest("[data-product-index]");
    if (wrap) openProduct(Number(wrap.dataset.productIndex));
  });

  productsGrid?.addEventListener("keydown", e => {
    const wrap = e.target.closest("[data-product-index]");
    if (wrap && (e.key === "Enter" || e.key === " ")) {
      e.preventDefault();
      openProduct(Number(wrap.dataset.productIndex));
    }
  });
}

byId("close")?.addEventListener("click", closeProductModal);
modal?.addEventListener("click", e => { if (e.target === modal) closeProductModal(); });
document.addEventListener("keydown", e => { if (e.key === "Escape") closeProductModal(); });
if (byId("year")) byId("year").textContent = new Date().getFullYear();

if (collectionsGrid) initHome();
if (productsGrid) initCollectionPage();
