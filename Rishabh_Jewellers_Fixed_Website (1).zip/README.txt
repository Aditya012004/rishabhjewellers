# Rishabh Jewellers — Fixed Website

## What was changed
- Clicking **Open collection** opens the selected collection in a **new browser tab**.
- The new tab shows **only that collection's products**.
- **← Back to collections** returns to `index.html#collections`.
- Product images are clickable and open a larger preview.
- WhatsApp enquiry buttons are generated for every product.
- The four existing collections are preserved:
  - Tirupati Dollar — 13 products
  - Temple Antique Necklace — 13 products
  - Ganesha Pendant — 13 products
  - Calcutta Necklace — 23 products
- Collections are stored in one `collections` array in `script.js`, so new collections can be added by copying the same structure.
- CSS has been moved into `style.css` instead of being duplicated inside `index.html`.

## Images
The source code referenced image paths such as `images/tirupati-01.png`, but the uploaded source did not include the actual image files. This package therefore contains clearly labelled SVG placeholder images using those exact filenames.

To use your real photos, replace each placeholder file with your actual product image while keeping the same filename, or update the image path in `script.js`.

## Main files
- `index.html` — homepage
- `collection.html` — collection/product page
- `style.css` — all styling
- `script.js` — collections, products, modal and WhatsApp functionality
- `images/` — product image files/placeholders
